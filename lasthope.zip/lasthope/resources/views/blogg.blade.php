@extends('coba')

@section('judul', 'Halaman Blogg')

@section('isi')
        Ini Halaman Blogg
@endsection