@extends('coba')

@section('judul', 'Halaman About')

@section('isi')
        Ini Halaman About
@endsection