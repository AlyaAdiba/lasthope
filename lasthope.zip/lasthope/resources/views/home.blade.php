@extends('coba')

@section('judul', 'Halaman Home')

@section('isi')
        Welcome to AIMERCH!!
@endsection