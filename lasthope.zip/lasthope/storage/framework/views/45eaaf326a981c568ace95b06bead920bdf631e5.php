<!DOCTYPE html>
<html>
<head>
    <title><?php echo $__env->yieldContent('judul'); ?></title>
</head>
<body>
    <center>
        <h2>AIMERCH REVIEWS</h2>
        <p>Tempatnya mereview sebuah merch!</p>
        <a href="/home">Home</a>
        <a href="/about">About</a>
        <a href="/review">Review</a>

        <hr>
            <?php echo $__env->yieldContent('isi'); ?>
        <hr>
        Copyright@2022 by Alya Adiba
    </center>
</body>
</html><?php /**PATH C:\xampp\lasthope\resources\views/coba.blade.php ENDPATH**/ ?>