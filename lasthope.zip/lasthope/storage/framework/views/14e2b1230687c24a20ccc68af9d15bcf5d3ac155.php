

<?php $__env->startSection('Judul', 'HALAMAN DARTIKEL'); ?>

<?php $__env->startSection('isi'); ?>
    <div class="pagetitle">
        <h1>Halaman untuk data artikel</h1>
        <nav>
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item">Pages</li>
            <li class="breadcrumb-item active">Articles Data</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
            <div class="row">
                <div class="col-sm-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Basic table
                        </header>
                    </section>
                </div>
            </div>
            <!-- page start -->
            Halaman Dartikel
            <!-- page end -->
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\lasthope\resources\views/admin/dartikel.blade.php ENDPATH**/ ?>