

<?php $__env->startSection('judul', 'Halaman Home'); ?>

<?php $__env->startSection('isi'); ?>
        Welcome to AIMERCH!!
<?php $__env->stopSection(); ?>
<?php echo $__env->make('coba', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\lasthope\resources\views/home.blade.php ENDPATH**/ ?>